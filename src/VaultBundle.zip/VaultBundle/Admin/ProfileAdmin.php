<?php

namespace VaultBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;

class ProfileAdmin extends AbstractAdmin {

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper) {
        $datagridMapper
                ->add('id')
                ->add('isDeleted')
                ->add('modifiedBy')
                ->add('createdAt')
                ->add('updatedAt')
                ->add('firstName')
                ->add('lastName')
                ->add('title')
                ->add('email')
                ->add('gender')
                ->add('address')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper) {
        $listMapper
                ->add('id')
                //->add('isDeleted')
                //->add('modifiedBy')
                //->add('createdAt')
                //->add('updatedAt')
                ->add('firstName')
                ->add('lastName')
                ->add('title')
                ->add('email')
                //->add('gender')
                //->add('address')
                ->add('_action', null, array(
                    'actions' => array(
                        'show' => array(),
                        'edit' => array(),
                        'delete' => array(),
                    )
                ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper) {
        $formMapper
                ->add('userId')
//                ->add('userId', 'sonata_type_model', array('label' => 'Parent'))
//                ->add('category', 'entity', array(
//                    'class' => 'AppBundle\Entity\Category',
//                    'property' => 'name',
//                ))
                ->add('isDeleted')
                ->add('modifiedBy')
                ->add('createdAt')
                ->add('updatedAt')
                ->add('firstName')
                ->add('lastName')
                ->add('title')
                ->add('email')
                ->add('gender')
                ->add('address')
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper) {
        $showMapper
                ->add('id')
                ->add('isDeleted')
                ->add('modifiedBy')
                ->add('createdAt')
                ->add('updatedAt')
                ->add('firstName')
                ->add('lastName')
                ->add('title')
                ->add('email')
                ->add('gender')
                ->add('address')
        ;
    }

}
