<?php

namespace VaultBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class VaultBundle extends Bundle
{
}
